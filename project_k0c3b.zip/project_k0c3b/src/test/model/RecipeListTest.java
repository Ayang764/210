package model;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class RecipeListTest {
    private RecipeList testRecipeList;
    private Recipe recipe1;
    private Recipe recipe2;
    private Recipe recipe3;
    private Recipe recipe4;

    @BeforeEach
    void setup() {
        testRecipeList = new RecipeList();
        recipe1 = new Recipe("Pasta",15,2);
        recipe2 = new Recipe("Steak", 30, 3);
        recipe3 = new Recipe("BLT", 10, 1);
        recipe4 = new Recipe("Eggs", 5, 1);

    }

    @Test
    void testEmptyRecipeList() {
        assertEquals(0, testRecipeList.length());
    }

    @Test
    void testAddOneRecipe() {
        testRecipeList.addRecipe(recipe1);

        assertEquals(1, testRecipeList.length());

        List recipeNames = new ArrayList();
        recipeNames = testRecipeList.getRecipeNames();

        assertEquals(1, recipeNames.size());
        assertEquals("Pasta", recipeNames.get(0));

    }

    @Test
    void testAddMultipleRecipes() {
        testRecipeList.addRecipe(recipe1);
        testRecipeList.addRecipe(recipe2);
        testRecipeList.addRecipe(recipe3);
        testRecipeList.addRecipe(recipe4);

        assertEquals(4, testRecipeList.length());

        List recipeNames = new ArrayList();
        recipeNames = testRecipeList.getRecipeNames();

        assertEquals(4, recipeNames.size());
        assertEquals("Pasta", recipeNames.get(0));
        assertEquals("Steak", recipeNames.get(1));
        assertEquals("BLT", recipeNames.get(2));
        assertEquals("Eggs", recipeNames.get(3));
    }

    @Test
    void testSearchByIngredientFoundNone() {
        recipe1.addIngredient("Garlic");

        testRecipeList.addRecipe(recipe1);

        assertEquals(0,testRecipeList.getRecipesByIngredient("Tomato").size());
    }

    @Test
    void testSearchByIngredientFoundOne() {
        recipe1.addIngredient("Garlic");
        recipe1.addIngredient("Tomato");

        testRecipeList.addRecipe(recipe1);

        assertEquals(1,testRecipeList.getRecipesByIngredient("Tomato").size());
        assertEquals("Pasta", testRecipeList.getRecipesByIngredient("Tomato").get(0));
    }

    @Test
    void testSearchByIngredientFoundMultiple() {
        recipe1.addIngredient("Garlic");
        recipe1.addIngredient("Tomato");
        recipe2.addIngredient("Thyme");
        recipe3.addIngredient("Tomato");
        recipe4.addIngredient("Bread");

        testRecipeList.addRecipe(recipe1);
        testRecipeList.addRecipe(recipe2);
        testRecipeList.addRecipe(recipe3);
        testRecipeList.addRecipe(recipe4);

        assertEquals(2, testRecipeList.getRecipesByIngredient("Tomato").size());
        assertEquals("Pasta", testRecipeList.getRecipesByIngredient("Tomato").get(0));
        assertEquals("BLT", testRecipeList.getRecipesByIngredient("Tomato").get(1));

    }

    @Test
    void testSearchByNameFoundNone() {
        testRecipeList.addRecipe(recipe1);

        assertEquals(0, testRecipeList.getRecipesByName("Rice").size());
    }

    @Test
    void testSearchByNameFoundOne() {
        testRecipeList.addRecipe(recipe1);
        testRecipeList.addRecipe(recipe2);
        testRecipeList.addRecipe(recipe3);
        testRecipeList.addRecipe(recipe4);

        assertEquals(1, testRecipeList.getRecipesByName("Pasta").size());
        assertEquals("Pasta", testRecipeList.getRecipesByName("Pasta").get(0));
    }

    @Test
    void testSearchByNameFoundMultiple() {
        testRecipeList.addRecipe(recipe1);
        testRecipeList.addRecipe(recipe1);
        testRecipeList.addRecipe(recipe3);
        testRecipeList.addRecipe(recipe4);

        assertEquals(2, testRecipeList.getRecipesByName("Pasta").size());
        assertEquals("Pasta", testRecipeList.getRecipesByName("Pasta").get(0));
        assertEquals("Pasta", testRecipeList.getRecipesByName("Pasta").get(1));
    }




}
