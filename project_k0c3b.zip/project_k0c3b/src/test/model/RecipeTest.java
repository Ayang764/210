package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class RecipeTest {
    private Recipe testRecipe;

    @BeforeEach
    void setup(){
        testRecipe = new Recipe("Pasta",15, 2);
    }

    @Test
    void testConstructor(){
        assertEquals("Pasta", testRecipe.getName());
        assertEquals(15, testRecipe.getTime());
        assertEquals(2, testRecipe.getServings());
    }

    @Test
    void testNoIngredients(){
        List listOfIngredients = new ArrayList<>();
        listOfIngredients = testRecipe.getIngredients();

        assertTrue(listOfIngredients.isEmpty());
    }

    @Test
    void testAddOneIngredient(){
        testRecipe.addIngredient("500 grams of Pasta noodles");

        List listOfIngredients = new ArrayList<>();
        listOfIngredients = testRecipe.getIngredients();

        assertEquals(1,listOfIngredients.size());
        assertEquals("500 grams of Pasta noodles", listOfIngredients.get(0));
    }

    @Test
    void testAddMultipleIngredients(){
        testRecipe.addIngredient("500 grams of Pasta noodles");
        testRecipe.addIngredient("Half cup of olive oil");
        testRecipe.addIngredient("6 cloves of garlic");
        testRecipe.addIngredient("1 cup of grated parmesan");
        testRecipe.addIngredient("Quarter cup of chopped parsley");

        List listOfIngredients = new ArrayList<>();
        listOfIngredients = testRecipe.getIngredients();

        assertEquals(5,listOfIngredients.size());
        assertEquals("500 grams of Pasta noodles", listOfIngredients.get(0));
        assertEquals("Half cup of olive oil", listOfIngredients.get(1));
        assertEquals("6 cloves of garlic", listOfIngredients.get(2));
        assertEquals("1 cup of grated parmesan", listOfIngredients.get(3));
        assertEquals("Quarter cup of chopped parsley", listOfIngredients.get(4));
    }

    @Test
    void testNoSteps(){
        List listOfSteps = new ArrayList<>();
        listOfSteps = testRecipe.getSteps();

        assertTrue(listOfSteps.isEmpty());
    }

    @Test
    void testAddOneStep(){
        testRecipe.addStep("Boil and season water");

        List listOfSteps = new ArrayList<>();
        listOfSteps = testRecipe.getSteps();

        assertEquals(1, listOfSteps.size());
        assertEquals("Boil and season water", listOfSteps.get(0));
    }

    @Test
    void testMultipleSteps(){
        testRecipe.addStep("Boil and season water");
        testRecipe.addStep("Cook pasta in water until al dente");
        testRecipe.addStep("Slice garlic finely");
        testRecipe.addStep("While pasta is cooking fry garlic with olive oil in a pan");
        testRecipe.addStep("Once pasta is done cooking throw into pan");
        testRecipe.addStep("Mix in parsley and parmesan");

        List listOfSteps = new ArrayList<>();
        listOfSteps = testRecipe.getSteps();

        assertEquals(6, listOfSteps.size());
        assertEquals("Boil and season water", listOfSteps.get(0));
        assertEquals("Cook pasta in water until al dente", listOfSteps.get(1));
        assertEquals("Slice garlic finely", listOfSteps.get(2));
        assertEquals("While pasta is cooking fry garlic with olive oil in a pan", listOfSteps.get(3));
        assertEquals("Once pasta is done cooking throw into pan", listOfSteps.get(4));
        assertEquals("Mix in parsley and parmesan", listOfSteps.get(5));

    }

}
