package model;

import org.json.JSONObject;
import persistence.Json;

import java.util.ArrayList;
import java.util.List;

//Represents a recipe having a name, cook time, servings, ingredients and steps'
public class Recipe implements Json {
    private String name;
    private int time; //In MINUTES
    private int servings;
    private List<String> steps;
    private List<String> ingredients;

    //Constructs a recipe
    //REQUIRES: cookTime > 0, numServings > 0
    //EFFECTS: Constructs a recipe with name recipeName, time cookTime, servings numServings, and no
    //         steps and ingredients.
    public Recipe(String recipeName, int cookTime, int numServings) {
        name = recipeName;
        time = cookTime;
        servings = numServings;
        steps = new ArrayList();
        ingredients = new ArrayList();
    }

    public String getName() {
        return name;
    }

    public int getTime() {
        return time;
    }

    public int getServings() {
        return servings;
    }

    public List<String> getSteps() {
        return steps;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    //MODIFIES: this
    //EFFECTS: adds i to list of ingredients
    public void addIngredient(String i) {
        ingredients.add(i);
    }

    //MODIFIES: this
    //EFFECTS: adds s to to list of steps
    public void addStep(String s) {
        steps.add(s);
    }

    //Adapted from Json Demo
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("name", name);
        json.put("time", time);
        json.put("servings", servings);
        json.put("steps", steps);
        json.put("ingredients", ingredients);
        return json;
    }
}




