package model;


import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Json;

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

// Represents a list of recipes
public class RecipeList implements Json {

    private List<Recipe> recipes;

    //Constructs a list of recipes
    public RecipeList() {
        recipes = new ArrayList<>();
    }

    //EFFECTS: returns the number off recipes in the list
    public int length() {
        return recipes.size();
    }


    // EFFECTS: returns an unmodifiable list of thingies in this workroom
    public List<Recipe> getRecipes() {
        return Collections.unmodifiableList(recipes);
    }

    //EFFECTS: returns a list of all recipe names
    public List<String> getRecipeNames() {
        List nameList = new ArrayList();
        for (Recipe r : recipes) {
            nameList.add(r.getName());
        }
        return nameList;
    }


    //EFFECTS: returns a list of all recipes with ingredient i
    public List<String> getRecipesByIngredient(String i) {
        List ingredientList = new ArrayList();
        for (Recipe r : recipes) {
            List<String> ingredients = r.getIngredients();
            for (String s : ingredients) {
                if (s.equals(i)) {
                    ingredientList.add(r.getName());
                }

            }
        }
        return ingredientList;
    }

    //EFFECTS: returns a list of all recipes with name n
    public List<String> getRecipesByName(String n) {
        List nameList = new ArrayList();
        for (Recipe r : recipes) {
            if (r.getName().equals(n)) {
                nameList.add(r.getName());
            }

        }
        return nameList;
    }

    //REQUIRES: r must not be a recipe already in the list of recipes
    //MODIFIES: this
    //EFFECTS: adds a recipe r to the list of recipes
    public void addRecipe(Recipe r) {
        recipes.add(r);
    }

    //Adapted from Json demo
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("recipes", recipesToJson());
        return json;
    }

    // EFFECTS: returns recipes in this recipe list as a JSON array
    private JSONArray recipesToJson() {
        JSONArray jsonArray = new JSONArray();

        for (Recipe r : recipes) {
            jsonArray.put(r.toJson());
        }

        return jsonArray;
    }
}
