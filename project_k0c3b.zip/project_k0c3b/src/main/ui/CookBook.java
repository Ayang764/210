package ui;

import model.Recipe;
import model.RecipeList;

import java.io.FileNotFoundException;
import java.io.IOException;

import persistence.JsonReader;
import persistence.JsonWriter;

import java.util.Scanner;

public class CookBook {

    private static final String JSON_STORE = "./data/RecipeList.json";
    private Scanner input;
    private RecipeList recipes;
    private Recipe recipe;
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;

    // Based off of teller app and json demo
    // EFFECTS: opens the cookbook
    public CookBook() {
        openCookBook();
    }

    // MODIFIES: this
    // EFFECTS: processes user input
    private void openCookBook() {
        boolean keepGoing = true;
        String command = null;

        init();

        while (keepGoing) {
            displayMenu();
            command = input.next();
            command = command.toLowerCase();

            if (command.equals("q")) {
                keepGoing = false;
            } else {
                processCommand(command);
            }
        }

        System.out.println("\nGoodbye!");
    }

    //EFFECTS: initializes a new list of recipes
    public void init() {
        recipes = new RecipeList();
        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);
        input = new Scanner(System.in);
    }

    //EFFECTS: displays a menu of options for user
    public void displayMenu() {
        System.out.println("\nSelect from:");
        System.out.println("\ti -> input a recipe");
        System.out.println("\tl -> look at all recipes");
        System.out.println("\ts -> search for a recipe");
        System.out.println("\tsv -> save recipe list to file");
        System.out.println("\tld -> load recipe list from file");
        System.out.println("\tq -> quit");
    }

    //EFFECTS: processes user input
    public void processCommand(String command) {
        if (command.equals("i")) {
            inputRecipe();
        } else if (command.equals("l")) {
            listOfAllRecipes();
        } else if (command.equals("s")) {
            searchForRecipe();
        } else if (command.equals("sv")) {
            saveRecipeList();
        } else if (command.equals("ld")) {
            loadRecipeList();
        } else {
            System.out.println("Selection not valid...");
        }

    }


    //MODIFIES: this
    //EFFECTS: inputs a new recipe into the list of recipes
    public void inputRecipe() {
        System.out.println("Name your recipe");
        String name = input.next();
        System.out.println("How much time does your recipe take (in minutes)");
        int time = input.nextInt();
        System.out.println("How many servings does your recipe yield?");
        int servings = input.nextInt();

        recipe = new Recipe(name, time, servings);

        inputIngredients();
        inputSteps();

        recipes.addRecipe(recipe);

    }

    //EFFECTS: inputs the steps into a recipe
    public void inputSteps() {
        System.out.println("How many steps does this recipe have?");
        int numStep = input.nextInt();
        for (int i = 1; i <= numStep; i++) {
            System.out.println("Input step " + i);
            String step = input.next();
            recipe.addStep(step);
        }
    }

    //EFFECTS: inputs the ingredients into a recipe
    public void inputIngredients() {
        System.out.println("How many ingredients does this recipe have?");
        int numIng = input.nextInt();
        for (int i = 1; i <= numIng; i++) {
            System.out.println("Input an ingredient");
            String ing = input.next();
            recipe.addIngredient(ing);
        }
    }


    //EFFECTS: returns a list off all the recipes
    public void listOfAllRecipes() {
        System.out.println("Here is a list of all recipes:");
        System.out.println(recipes.getRecipeNames());
    }

    //EFFECTS: processes whether to search by ingredient or name
    public void searchForRecipe() {
        System.out.println("Select from:");
        System.out.println("\ti -> search by ingredient");
        System.out.println("\tn -> search by name");

        String search = input.next();

        if (search.equals("i")) {
            searchByIngredient();
        } else if (search.equals("n")) {
            searchByName();
        } else {
            System.out.println("Selection not valid...");
        }
    }

    //EFFECTS: searches recipes by ingredient
    public void searchByIngredient() {
        System.out.println("What ingredient do you want to search by:");

        String ingredient = input.next();

        System.out.println("These are the recipes that include " + ingredient + ":");
        System.out.println(recipes.getRecipesByIngredient(ingredient));
    }

    //EFFECTS: searches recipes by name
    public void searchByName() {
        System.out.println("What name do you want to search by:");

        String name = input.next();

        System.out.println("These are the recipes that are named " + name + ":");
        System.out.println(recipes.getRecipesByName(name));
    }

    // EFFECTS: saves the workroom to file
    private void saveRecipeList() {
        try {
            jsonWriter.open();
            jsonWriter.write(recipes);
            jsonWriter.close();
            System.out.println("Saved to " + JSON_STORE);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to write to file: " + JSON_STORE);
        }
    }

    // MODIFIES: this
    // EFFECTS: loads workroom from file
    private void loadRecipeList() {
        try {
            recipes = jsonReader.read();
            System.out.println("Loaded from " + JSON_STORE);
        } catch (IOException e) {
            System.out.println("Unable to read from file: " + JSON_STORE);
        }
    }


}
