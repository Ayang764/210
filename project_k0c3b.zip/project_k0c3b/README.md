# My Personal Project

## Introduction

<p> This application will store recipes as well as have a calendar for when to use which recipes.
This application can be used by amateur home cooks or professional chefs.
This project is of interest to me because I frequently cook at home and consider it a hobby. I enjoy trying different
recipes I find online, so I would like to use this application as a way to store all the recipes I find.</p>

## User Stories
- As a user, I want to be able to input and save a recipe to my list of recipes
- As a user, I want to be able to see a list of all my recipes
- As a user, I want to be able to search for a recipe by ingredients
- As a user, I want to be able to search for a recipe by name
- As a user, I want to be able to save the state of my recipe list
- As a user, I want to be able to reload that state from file and resume
 exactly where I left off at some earlier time


