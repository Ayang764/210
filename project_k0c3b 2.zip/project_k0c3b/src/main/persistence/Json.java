package persistence;

import org.json.JSONObject;


//Based off json demo
//interface for JsonReader and JsonWriter

public interface Json {
    // EFFECTS: returns this as JSON object
    JSONObject toJson();
}
