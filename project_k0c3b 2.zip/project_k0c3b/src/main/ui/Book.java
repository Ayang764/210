package ui;

import model.RecipeList;
import persistence.JsonReader;
import persistence.JsonWriter;
import ui.popups.InputPopUp;
import ui.popups.SearchPopUp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

//Center of control for GUI implementation

public class Book extends JFrame implements ActionListener {

    public static final int WIDTH = 500;
    public static final int HEIGHT = 700;
    private static final String JSON_STORE = "./data/RecipeList.json";
    private JButton button;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private RecipeList recipes;
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;
    private ImageIcon cookBook;
    private SearchPopUp searchPopUp;
    private InputPopUp inputPopUp;
    

    //EFFECTS: Creates a new Book
    public Book() {
        setLayout(new FlowLayout());
        setMinimumSize(new Dimension(WIDTH, HEIGHT));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        jsonWriter = new JsonWriter(JSON_STORE);
        jsonReader = new JsonReader(JSON_STORE);

        recipes = new RecipeList();

        cookBook = new ImageIcon("CookBook.jpg");
        JLabel label = new JLabel(cookBook);
        add(label);

        createTools();

        setVisible(true);
    }

    //EFFECTS: instantiates all tools
    public void createTools() {
        button = new JButton("Input A Recipe");
        button.addActionListener(this);
        add(button);

        button1 = new JButton("Search For A Recipe");
        button1.addActionListener(this);
        add(button1);

        button2 = new JButton("See All Recipes");
        button2.addActionListener(this);
        add(button2);

        button3 = new JButton("Save");
        button3.addActionListener(this);
        add(button3);

        button4 = new JButton("Load");
        button4.addActionListener(this);
        add(button4);

    }

    public RecipeList getRecipes() {
        return recipes;
    }

    //EFFECTS: does something if a button is pressed: - if button 1, creates a popup to input a recipe
    //                                                - if button 2, creates a popup to search recipes
    //                                                - if button 3, saves all data
    //                                                - if button 4, loads all data
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
            inputPopUp = new InputPopUp(recipes);
        }
        if (e.getSource() == button1) {
            searchPopUp = new SearchPopUp(recipes);
        }
        if (e.getSource() == button2) {
            createWindow();
        }
        if (e.getSource() == button3) {
            saveRecipeList();
        }

        if (e.getSource() == button4) {
            loadRecipeList();
        }
    }

    //Code adapted from ListDemo.java from Oracle
    //EFFECTS: creates a new window containing a list of all recipes
    private void createWindow() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        List allRecipes = recipes.getRecipeNames();
        JComponent newContentPane = new ListOfRecipePanel(allRecipes);
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);

        frame.pack();
        frame.setVisible(true);
    }

    // EFFECTS: saves the workroom to file
    private void saveRecipeList() {
        try {
            jsonWriter.open();
            jsonWriter.write(recipes);
            jsonWriter.close();
            System.out.println("Saved to " + JSON_STORE);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to write to file: " + JSON_STORE);
        }
    }

    // MODIFIES: this
    // EFFECTS: loads workroom from file
    private void loadRecipeList() {
        try {
            recipes = jsonReader.read();
            System.out.println("Loaded from " + JSON_STORE);
        } catch (IOException e) {
            System.out.println("Unable to read from file: " + JSON_STORE);
        }
    }
}

