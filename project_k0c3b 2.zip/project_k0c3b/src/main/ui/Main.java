package ui;

//Starts program

public class Main {
    public static void main(String[] args) {
        new Book();
    }
}
