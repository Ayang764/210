package ui.popups;

import model.RecipeList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Class that creates a new popup window

public abstract class PopUp extends JFrame implements ActionListener {

    public static final int WIDTH =  300;
    public static final int HEIGHT = 400;
    protected RecipeList recipes;
    protected JPanel toolArea;

    public PopUp(RecipeList recipes) {

        toolArea = new JPanel();
        toolArea.setLayout(new GridLayout(0,1));
        toolArea.setSize(new Dimension(0, 0));
        add(toolArea);

        this.recipes = recipes;

        setLayout(new FlowLayout());
        setMinimumSize(new Dimension(WIDTH, HEIGHT));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

    }

    @Override
    public abstract void actionPerformed(ActionEvent e);
}
