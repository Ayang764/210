package ui.popups;

import model.RecipeList;
import ui.ListOfRecipePanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

//Class that creates a new popup window where you can search for a recipe

public class SearchPopUp extends PopUp {

    private JButton button1;
    private JButton button2;
    private JTextField nameField;
    private JTextField ingredientField;

    //EFFECTS: creates a popup where you can search for recipes by name or ingredient
    public SearchPopUp(RecipeList recipes) {
        super(recipes);

        button1 = new JButton("Search By Name");
        toolArea.add(button1);
        button1.addActionListener(this);
        nameField = new JTextField();
        toolArea.add(nameField);

        button2 = new JButton("Search By Ingredient");
        toolArea.add(button2);
        button2.addActionListener(this);
        ingredientField = new JTextField();
        toolArea.add(ingredientField);

        setVisible(true);
    }

    //Code adapted from ListDemo.java from Oracle
    //EFFECTS: does something if a button is pressed: - if button1, searches by name
    //                                                - if button2, searches by ingredient
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button1) {
            List recipeNames = recipes.getRecipesByName(nameField.getText());

            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            //Create and set up the content pane.
            JComponent newContentPane = new ListOfRecipePanel(recipeNames);
            newContentPane.setOpaque(true); //content panes must be opaque
            frame.setContentPane(newContentPane);

            //Display the window.
            frame.pack();
            frame.setVisible(true);
        }

        if (e.getSource() == button2) {
            List recipeIngredients = recipes.getRecipesByIngredient(ingredientField.getText());

            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            //Create and set up the content pane.
            JComponent newContentPane = new ListOfRecipePanel(recipeIngredients);
            newContentPane.setOpaque(true); //content panes must be opaque
            frame.setContentPane(newContentPane);

            //Display the window.
            frame.pack();
            frame.setVisible(true);
        }

    }
}
