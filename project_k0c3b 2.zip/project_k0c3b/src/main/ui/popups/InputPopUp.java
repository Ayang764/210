package ui.popups;

import model.Recipe;
import model.RecipeList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

//Class that creates a new popup window where you can input a recipe

public class InputPopUp extends PopUp {

    private JTextField nameField;
    private JTextField ingredientField;
    private JTextField stepField;
    private JButton nameButton;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private Recipe recipe;

    //EFFECTS: creates a popup where you can input a recipe
    public InputPopUp(RecipeList recipes) {
        super(recipes);

        initialize();

        toolArea.add(nameButton);
        nameButton.addActionListener(this);
        toolArea.add(nameField);


        toolArea.add(button1);
        button1.addActionListener(this);
        toolArea.add(ingredientField);


        toolArea.add(button2);
        button2.addActionListener(this);
        toolArea.add(stepField);


        toolArea.add(button3);
        button3.addActionListener(this);

        setVisible(true);
    }

    //EFFECTS: does something if a button is pushed: - if nameButton, inputs recipe name
    //                                               - if button1, inputs an ingredient to recipe
    //                                               - if button2, inputs a step to recipe
    //                                               - if button3, saves recipe to list of recipes
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nameButton) {
            recipe = new Recipe(nameField.getText());
        }
        if (e.getSource() == button1) {
            recipe.addIngredient(ingredientField.getText());
        }
        if (e.getSource() == button2) {
            recipe.addStep(stepField.getText());
        }
        if (e.getSource() == button3) {
            recipes.addRecipe(recipe);
        }
    }

    //EFFECTS: initializes all fields
    public void initialize() {
        nameButton = new JButton("Add Recipe Name");
        button1 = new JButton("Add Ingredient");
        button2 = new JButton("Add Step");
        button3 = new JButton("Save Recipe");
        nameField = new JTextField();
        ingredientField = new JTextField();
        stepField = new JTextField();
    }

}
