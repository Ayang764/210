package ui;

import javax.swing.*;
import java.awt.*;
import java.util.List;

//Creates a list of given recipe names

public class ListOfRecipePanel extends JPanel {

    private List<String> recipes;
    private DefaultListModel listModel;
    private JList list;

    //Code adapted from ListDemo.java from Oracle
    //EFFECTS: Creates a list of the given recipes
    public ListOfRecipePanel(List recipes) {
        super(new BorderLayout());

        this.recipes = recipes;

        listModel = new DefaultListModel();


        for (Object s : recipes) {
            listModel.addElement(s);
        }

        list = new JList(listModel);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setSelectedIndex(0);
        list.setVisibleRowCount(5);
        JScrollPane listScrollPane = new JScrollPane(list);
        add(listScrollPane, BorderLayout.CENTER);

    }
}
